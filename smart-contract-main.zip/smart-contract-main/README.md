# smart-contract
Black Doge BSC Smart Contract

### deployed contract on BSC mainnet: https://bscscan.com/token/0xbdff32474e3b2fde9ff306b9a8beffbc3c3dc0fd
