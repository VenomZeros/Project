# assets
all digital asset of blackdoge
